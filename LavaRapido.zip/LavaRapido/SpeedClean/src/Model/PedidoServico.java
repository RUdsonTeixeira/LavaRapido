
package Model;

import java.util.Date;


public class PedidoServico {
    private int codPedidoServico;
    private String descricao;
    private Date data;
    private int codCliente;
    private int codServico;

    public int getCodPedidoServico() {
        return codPedidoServico;
    }

    public void setCodPedidoServico(int codPedidoServico) {
        this.codPedidoServico = codPedidoServico;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public int getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(int codCliente) {
        this.codCliente = codCliente;
    }

    public int getCodServico() {
        return codServico;
    }

    public void setCodServico(int codServico) {
        this.codServico = codServico;
    }

    @Override
    public String toString() {
        return "PedidoServico{" + "codPedidoServico=" + codPedidoServico + ", descricao=" + descricao + ", data=" + data + ", codCliente=" + codCliente + ", codServico=" + codServico + '}';
    }
    
    
}
