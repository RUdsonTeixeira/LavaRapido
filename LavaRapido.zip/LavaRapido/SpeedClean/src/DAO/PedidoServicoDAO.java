package DAO;

import Conexao.ModuloConexao;
import Model.Cliente;
import Model.PedidoServico;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PedidoServicoDAO {

    private Connection connection = null;

    public PedidoServicoDAO() {
        ModuloConexao c = new ModuloConexao();
        this.connection = c.retornaConexao();
    }

    public void adiciona(PedidoServico pedido) throws SQLException {
        PreparedStatement stmt;

        stmt = this.connection.prepareStatement("INSERT INTO public.pedidoservico(descricao,codcliente,codservico,dataagendamento)values(?,?,?,?)");
        stmt.setString(1, pedido.getDescricao());
        stmt.setInt(2, pedido.getCodCliente());
        stmt.setInt(3, pedido.getCodServico());

        java.util.Date dataUtil = pedido.getData();
        java.sql.Date dataSql = new java.sql.Date(dataUtil.getTime());

        stmt.setDate(4, dataSql);
        stmt.execute();
        stmt.close();

    }
    
    public void edita(PedidoServico pedido) throws SQLException {
        PreparedStatement stmt;

        stmt = this.connection.prepareStatement("UPDATE public.pedidoservico\n" +
"	SET descricao=?, codcliente=?, codservico=?, dataagendamento=?\n" +
"	WHERE codpedidoservico = ?;");
        try {
        stmt.setString(1, pedido.getDescricao());
        stmt.setInt(2, pedido.getCodCliente());
        stmt.setInt(3, pedido.getCodServico());        

        java.util.Date dataUtil = pedido.getData();
        java.sql.Date dataSql = new java.sql.Date(dataUtil.getTime());

        stmt.setDate(4, dataSql);
        stmt.setInt(5, pedido.getCodPedidoServico());
        stmt.executeUpdate();
        stmt.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                stmt.close();

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }
        public ArrayList<Cliente> retorna() throws SQLException {
        ArrayList<Cliente> c = new ArrayList<Cliente>();

        PreparedStatement st = null;
        ResultSet rs = null;

        String sql = "SELECT * FROM \"pedidoservico\"";

        st = connection.prepareStatement(sql);
        rs = st.executeQuery();
        while (rs.next()) {
            Cliente x = new Cliente();
            x.setCodCliente(rs.getInt(1));
            x.setNome(rs.getString(2));
            x.setTelefone(rs.getString(3));
            x.setEmail(rs.getString(4));
            c.add(x);
        }
        return c;
    }

    public void excluir(int cod) throws SQLException {
        PreparedStatement stmt;
        stmt = this.connection.prepareStatement("DELETE FROM public.pedidoservico WHERE codpedidoservico = ?;");
        try {
            stmt.setInt(1, cod);
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                stmt.close();

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

}
