package DAO;

import Conexao.ModuloConexao;
import Model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClienteDAO {

    private Connection connection = null;

    public ClienteDAO() {
        ModuloConexao c = new ModuloConexao();
        this.connection = c.retornaConexao();
    }

    public void adiciona(Cliente cliente) throws SQLException {
        PreparedStatement stmt;

        stmt = this.connection.prepareStatement("INSERT INTO public.cliente(nome,telefone,email)values(?,?,?)");
        stmt.setString(1, cliente.getNome());
        stmt.setString(2, cliente.getTelefone());
        stmt.setString(3, cliente.getEmail());
        stmt.execute();
        stmt.close();

    }

    public ArrayList<Cliente> retorna() throws SQLException {
        ArrayList<Cliente> c = new ArrayList<Cliente>();

        PreparedStatement st = null;
        ResultSet rs = null;

        String sql = "SELECT * FROM \"cliente\"";

        st = connection.prepareStatement(sql);
        rs = st.executeQuery();
        while (rs.next()) {
            Cliente x = new Cliente();
            x.setCodCliente(rs.getInt(1));
            x.setNome(rs.getString(2));
            x.setTelefone(rs.getString(3));
            x.setEmail(rs.getString(4));
            c.add(x);
        }
        return c;
    }
}
    
