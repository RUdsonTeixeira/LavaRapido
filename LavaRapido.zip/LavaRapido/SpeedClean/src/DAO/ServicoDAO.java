
package DAO;

import Conexao.ModuloConexao;
import Model.Servico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class ServicoDAO {
    
    private Connection connection = null;
	
	public ServicoDAO(){
            ModuloConexao c = new ModuloConexao();
		this.connection = c.retornaConexao();
	}
	
	public void adiciona(Servico servico) throws SQLException{
		PreparedStatement stmt;

            stmt = this.connection.prepareStatement("insert into public.servico(descricao,valor)values(?,?)");
                stmt.setString(1, servico.getDescricao());
		stmt.setDouble(2, servico.getValor());
		stmt.execute();
		stmt.close();
			
	}
        
        public ArrayList<Servico> retorna() throws SQLException {
		ArrayList<Servico> c = new ArrayList<Servico>();

		PreparedStatement st = null;
		ResultSet rs = null;

		String sql = "SELECT * FROM \"servico\"";
	
			st = connection.prepareStatement(sql);
			rs = st.executeQuery();
			while (rs.next()) {
				Servico x = new Servico();                                
				x.setCodServico(rs.getInt(1));
				x.setDescricao(rs.getString(2));
                                x.setValor(rs.getDouble(3));
				c.add(x);
			}

		return c;
	}
    
}
