
package telaInicial;

import Conexao.ModuloConexao;
import Views.TelaLogin;


public class testeTelaInicio {


    public static void main(String[] args) {
        TelaLogin c = new TelaLogin();
        c.show();
    }
    
}
