
package Conexao;

import Views.TelaLogin;
import static Views.TelaLogin.con;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ModuloConexao {
    
    public static Connection con = null;
    
    public Connection retornaConexao(){
        System.out.println("Conectando ao banco...");
        try {

		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SpeedClean", "postgres", "123456");
            System.out.println("Conectado.");
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        }        
        return con;
    }
}
    
    

